<?php

define("DB_HOST", "localhost");
define("DB_USER", "almasap2_almasap2");
define("DB_PASSWORD", "Negin3526!!");
define("DB_DATABASE", "almasap2_db_notes");

$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE);
	
// 	if($conn){
// 		echo "success";
// 	}else
// 	{
// 	 echo "No connection";   
// 	}
?>